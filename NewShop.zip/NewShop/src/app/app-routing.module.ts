import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './auth/login/login.component';
import { RegisterComponent } from './auth/register/register.component';
import { ListComponent } from './Products/list/list.component';
import { AuthGuard } from './auth.guard';
import { DetailsComponent } from './Products/details/details.component';


const routes: Routes = [

  {
    path: "login",
    component: LoginComponent
  },
  {
    path: "register",
    component: RegisterComponent
  },
  {
    path: "dashboard",
    component: ListComponent, canActivate: [AuthGuard]
  },
  {
    path: "dashboard/add",
    component: DetailsComponent, canActivate: [AuthGuard]
  },
  {
    path: "dashboard/edit/:id",
    component: DetailsComponent, canActivate: [AuthGuard]
  }

];




@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
