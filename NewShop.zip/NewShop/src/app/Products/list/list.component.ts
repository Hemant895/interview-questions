import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { ShopService } from 'src/app/services/shop.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  products: any[] = [];
  searchQuery: string = '';
  currentPage: number = 1;
  pageSize: number = 10;
  totalPages: number = 0;
  totalProducts: number = 0;

  constructor(private productService: ShopService, private router: Router, private authService: AuthService) { }

  ngOnInit(): void {

    this.products = JSON.parse(localStorage.getItem('products') || '[]')
    console.log(this.products);


  }

  deleteproduct(id: any) {
    this.productService.deleteproduct(id).subscribe((product) => {
      if (product) {
        this.router.navigate(['/dashboard'])
      }
      else {
        alert('Failed to delete product')
      }
    })
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  search() {
    this.productService.search(this.searchQuery).subscribe((products) => {
      this.products = products;
    })
  }

  previousPage() {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.loadProducts();
    }
  }
  addProduct(product: any) {
    this.productService.addProduct(product).subscribe((product) => {
      if (product) {
        this.router.navigate(['/dashboard'])
      }
      else {
        alert('Failed to add product')
      }
    })
  }

  nextPage() {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.loadProducts();
    }
  }

  loadProducts() {
    this.productService.getAllproducts().subscribe((products) => {
      this.products = products;
    })
  }

}
