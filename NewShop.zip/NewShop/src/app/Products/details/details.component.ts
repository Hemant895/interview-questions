import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ShopService } from 'src/app/services/shop.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {

  productForm: FormGroup;
  editMode: boolean = false;
  constructor(private fb: FormBuilder, private productService: ShopService, private router: Router) { }

  ngOnInit(): void {
    this.productForm = this.fb.group({
      name: ['', Validators.required],
      Department: ['', Validators.required],
      Category: ['', Validators.required],
      Quantity: ['', Validators.required],
      Price: ['', Validators.required],
      Date: ['', Validators.required]
    })
  }


  onSubmit() {
    if (this.editMode) {
      this.updateproduct(this.productForm.value.id);
    }
    else {
      this.addProduct(this.productForm.value);
    }

  }
  addProduct(product: any) {
    this.productService.addProduct(product).subscribe((product) => {
      if (product) {
        this.router.navigate(['/dashboard'])
      }
      else {
        alert('Failed to add product')
      }
    })
  }


  deleteproduct(id: any) {
    this.productService.deleteproduct(id).subscribe((product) => {
      if (product) {
        this.router.navigate(['/dashboard'])
      }
      else {
        alert('Failed to delete product')
      }
    })
  }
  updateproduct(id: any) {
    this.productService.updateproduct(id).subscribe((product) => {
      if (product) {
        this.router.navigate(['/dashboard'])
      }
      else {
        alert('Failed to delete product')
      }
    })

  }
}
