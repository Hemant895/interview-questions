import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ShopService {
  private readonly productskey = "products"
  private Behavioursubject = new BehaviorSubject<any>(null);

  constructor() { }

  private getProductsList(): any[] {
    const productsInfo = localStorage.getItem(this.productskey);
    return productsInfo ? JSON.parse(productsInfo) : [];
  }

  getAllproducts(): Observable<any> {
    return of(this.getProductsList());
  }

  addProduct(product: any): Observable<any> {
    let products = this.getProductsList();
    products.push(product);
    this.Behavioursubject.next(product);
    localStorage.setItem(this.productskey, JSON.stringify(products));
    return of(true);
  }
  updateproduct(id: any) {
    let products = this.getProductsList();
    let product = products.find((p: any) => p.id === id);
    if (product) {
      product.name = product.name;
      product.price = product.price;
      product.description = product.description;
      this.Behavioursubject.next(product);
      localStorage.setItem(this.productskey, JSON.stringify(products));
      return of(true);
    }
    else {
      return of(false);
    }

  }

  deleteproduct(id: any) {
    let products = this.getProductsList();
    let productIndex = products.findIndex((p: any) => p.id === id);
    if (productIndex !== -1) {
      let product = products[productIndex];
      products.splice(productIndex, 1);
      this.Behavioursubject.next(product);
      localStorage.setItem(this.productskey, JSON.stringify(products));
      return of(true);
    } else {
      return of(false);
    }
  }

  search(query: string): Observable<any[]> {
    let products = this.getProductsList();
    return of(products.filter((p: any) => p.name.toLowerCase().includes(query.toLowerCase())));
  }

}

