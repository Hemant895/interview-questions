import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private readonly Alluserskey = "allusers"
  private readonly currentuserkey = "currentuser"
  constructor() { }

  getAllusers(): any[] {
    const usersInfo = localStorage.getItem(this.Alluserskey);
    return usersInfo ? JSON.parse(usersInfo) : [];
  }

  login(userData: any): Observable<any> {
    const users = this.getAllusers();
    const user = users.find((u: any) => u.username === userData.username && u.password === userData.password);

    if (user) {
      localStorage.setItem(this.currentuserkey, JSON.stringify(user));
    }

    return of(user);
  }

  register(user: any): Observable<any> {
    let users = this.getAllusers();
    let exist = users.find((u: any) => u.username === user.username);
    if (exist) {
      return of(false);
    }
    users.push(user);
    localStorage.setItem(this.Alluserskey, JSON.stringify(users));
    return of(true);
  }

  logout() {
    localStorage.removeItem(this.currentuserkey);
  }

  isLoggedIn(): boolean {
    return localStorage.getItem(this.currentuserkey) !== null;
  }

  getCurrentUser(): any {
    return JSON.parse(localStorage.getItem(this.currentuserkey) || '{}');
  }


}
