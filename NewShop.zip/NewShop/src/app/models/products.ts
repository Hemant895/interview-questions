export interface Products {
    id: number;
    "Product Name": string;
    "Department": string;
    "Category": string;
    "Quantity": number;
    "Price": number;
    "Date Added": string;

}
